package yEnc;

# by Jeremy Nixon, copyright (c) 2002
#
# This code is released under the BSD License.  See the included
# LICENSE file for details.
#
# This is intended as a test module for using yEnc as a MIME
# transfer-encoding.  It is a subclass of MIME::Decoder, and
# requires that the MIME::Tools package be installed.  It works
# as a decoder within MIME::Tools.

use strict;
use base qw(MIME::Decoder);

# Encodes the input into yEnc.  Because of the stupid =ybegin crap,
# we can't do this as a stream; we have to wait until we know how
# big the original datastream is, which means we can't write any
# output until we've read all of the input.  We also have to go
# looking at our MIME headers for a filename to use.  This code
# doesn't support multipart binaries simply because the =ybegin
# and =ypart and =yend requirements for those make it impossible
# to do so here.  The reason we are torturing ourselves like this
# is backwards compatibility.  Note to those who say that keeping
# the =ybegin nonsense forever won't hurt anything: phooey.
sub encode_it {
    my $self = shift;
    my $in = shift;
    my $out = shift;

    my $linelength = 990; # target post-encoding line length

    my $head = $self->head;
    my $filename = $head->recommended_filename || 'nofilename';

    my $inbuffer;
    my $outbuffer;
    my $origsize = 0;
    my $linepos = 1;
    while (my $rlen = $in->read($inbuffer,1024)) {
        $origsize += $rlen;
        my $off = 0;
        while ($off < length($inbuffer)) {
            my $byte = substr($inbuffer,$off++,1);
            my $outval = (ord($byte) + 42) % 256;
            if ($outval == 0x00 or
                $outval == 0x0a or
                $outval == 0x0d or
                $outval == 0x3d or
                ($linepos == 1 and $outval == 0x2e)) {
                    $outval = chr(($outval + 64) % 256);
                    $outval = "=$outval";
            } else {
                $outval = chr($outval);
            }
            $outbuffer .= $outval;
            $linepos += length($outval);
            if ($linepos >= $linelength) {
                $outbuffer .= "\r\n";
                $linepos = 1;
            }
        }
        $inbuffer = '';
    }
    if ($outbuffer !~ /\r\n$/) { $outbuffer .= "\r\n" }

    my $ybegin = "=ybegin line=$linelength size=$origsize name=$filename";
    my $yend = "=yend size=$origsize";

    $out->print("$ybegin\r\n");
    $out->print($outbuffer);
    $out->print("$yend\r\n");
    return 1;
}

# Decodes the input from yEnc back to original form.
sub decode_it {
    my $self = shift;
    my $in = shift;
    my $out = shift;

    my $indata;
    while (my $data = $in->getline) {
        my $outdata = '';
        last if ($data =~ /^=yend/); # end of data
        next if ($data =~ /^=y/); # ignore comment lines
        my $linepos = 0;
        while ($linepos < length($data)) {
            my $pre = substr($data,$linepos,1);
            ($linepos++, next) if ($pre eq "\r" or $pre eq "\n");
            if ($pre eq '=') {
                $pre = substr($data,++$linepos,1);
                $outdata .= chr((((ord($pre) - 64) % 256 ) - 42) % 256);
            } else {
                $outdata .= chr((ord($pre) - 42) % 256);
            }
            $linepos++;
        }
        $out->print($outdata);
    }

    return 1;
}


1;
